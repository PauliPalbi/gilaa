This package is intented to help streamline the process of getting data from the GALAH survey / other databases. Cool features to come! 
